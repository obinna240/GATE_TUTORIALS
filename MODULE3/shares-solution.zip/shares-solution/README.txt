Create a gazetteer using the lists.def file in the gazetteer directory.

Create a JAPE Transducer using the main.jape file in the jape directory.

Add them at the end of the default ANNIE application.
